package com.example.sticklab

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.input.InputManager
import android.view.InputDevice
import android.view.MotionEvent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

/**
 * Tela de diagnóstico: só LÊ informações do sistema pelo Shizuku.
 * Não injeta nada nem altera o controle. Serve para descobrir o que é possível.
 */
class DiagActivity : Activity(),
    Shizuku.OnRequestPermissionResultListener,
    Shizuku.OnBinderReceivedListener,
    Shizuku.OnBinderDeadListener {

    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var runBtn: Button
    private lateinit var virtBtn: Button
    private lateinit var grabBtn: Button

    // Teste de bloqueio: instantes (ms) dos movimentos do controle real vistos por este app
    private val padEvents = ArrayList<Long>()
    private var grabTesting = false
    private lateinit var inputManager: InputManager

    // Resultado do teste do controle virtual
    private var vRecognized = false
    private var vInfo = ""
    private var vCount = 0
    private var vMin = 999f
    private var vMax = -999f

    private val devListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            val d = InputDevice.getDevice(deviceId) ?: return
            if (d.name == VNAME) {
                vRecognized = true
                vInfo = "id ${d.id}, fontes 0x${Integer.toHexString(d.sources)}"
            }
        }
        override fun onInputDeviceRemoved(deviceId: Int) {}
        override fun onInputDeviceChanged(deviceId: Int) {}
    }

    companion object {
        const val VNAME = "StickLab Virtual Gamepad"
    }

    private fun alive(): Boolean = try { Shizuku.pingBinder() } catch (t: Throwable) { false }

    private fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) { false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f }
        output = TextView(this).apply {
            setTextColor(Color.rgb(170, 255, 170))
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            text = "Toque em \"Rodar diagnóstico\" para começar."
        }

        val permBtn = Button(this).apply {
            text = "1) Pedir permissão do Shizuku"
            setOnClickListener { askPermission() }
        }
        runBtn = Button(this).apply {
            text = "2) Rodar diagnóstico"
            setOnClickListener { runDiagnostic() }
        }
        virtBtn = Button(this).apply {
            text = "3) Testar controle virtual"
            setOnClickListener { runVirtualTest() }
        }
        grabBtn = Button(this).apply {
            text = "4) Testar bloqueio do controle real"
            setOnClickListener { runGrabTest() }
        }
        val copyBtn = Button(this).apply {
            text = "5) Copiar resultado"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("sticklab-diag", output.text))
                Toast.makeText(this@DiagActivity, "Copiado. Cole na conversa.", Toast.LENGTH_SHORT).show()
            }
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            addView(TextView(this@DiagActivity).apply {
                text = "Diagnóstico (Shizuku)"
                setTextColor(Color.WHITE)
                textSize = 20f
            })
            addView(status)
            addView(permBtn)
            addView(runBtn)
            addView(virtBtn)
            addView(grabBtn)
            addView(copyBtn)
            addView(output)
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.rgb(18, 18, 24))
            addView(panel)
        })

        Shizuku.addRequestPermissionResultListener(this)
        Shizuku.addBinderReceivedListenerSticky(this)
        Shizuku.addBinderDeadListener(this)
        inputManager = getSystemService(Context.INPUT_SERVICE) as InputManager
        inputManager.registerInputDeviceListener(devListener, null)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onDestroy() {
        inputManager.unregisterInputDeviceListener(devListener)
        Shizuku.removeRequestPermissionResultListener(this)
        Shizuku.removeBinderReceivedListener(this)
        Shizuku.removeBinderDeadListener(this)
        super.onDestroy()
    }

    override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
        runOnUiThread { refreshStatus() }
    }

    override fun onBinderReceived() {
        runOnUiThread { refreshStatus() }
    }

    override fun onBinderDead() {
        runOnUiThread { refreshStatus() }
    }

    private fun refreshStatus() {
        val sb = StringBuilder()
        if (!alive()) {
            sb.append("Shizuku: NÃO está ativo.\n")
            sb.append("Abra o app Shizuku e toque em Iniciar (pela Depuração sem fio), depois volte aqui.")
        } else {
            val uid = try { Shizuku.getUid() } catch (t: Throwable) { -1 }
            val who = when (uid) {
                0 -> "root"
                2000 -> "adb/shell"
                else -> "uid $uid"
            }
            sb.append("Shizuku: ativo ($who)\n")
            sb.append(
                if (granted()) "Permissão: concedida"
                else "Permissão: ainda não concedida. Toque no botão 1."
            )
        }
        status.text = sb.toString()
    }

    private fun askPermission() {
        if (!alive()) {
            Toast.makeText(this, "Shizuku não está ativo.", Toast.LENGTH_LONG).show()
            return
        }
        if (granted()) {
            Toast.makeText(this, "Já tem permissão.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                Toast.makeText(
                    this,
                    "Permissão negada antes. Libere o StickLab dentro do app Shizuku.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Shizuku.requestPermission(1001)
            }
        } catch (t: Throwable) {
            Toast.makeText(this, "Erro: $t", Toast.LENGTH_LONG).show()
        }
    }

    // O método newProcess é privado nas versões novas da API, então chamo por reflexão.
    private fun shell(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim().ifEmpty { "(sem saída)" }
        } catch (t: Throwable) {
            "ERRO: ${t.cause ?: t}"
        }
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (grabTesting && e.isFromSource(InputDevice.SOURCE_JOYSTICK) &&
            e.action == MotionEvent.ACTION_MOVE && e.device?.name != VNAME
        ) {
            if (padEvents.size < 50000) padEvents.add(System.currentTimeMillis())
        }
        if (e.device?.name == VNAME && e.action == MotionEvent.ACTION_MOVE) {
            vCount++
            val x = e.getAxisValue(MotionEvent.AXIS_X)
            if (x < vMin) vMin = x
            if (x > vMax) vMax = x
            return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    private fun runVirtualTest() {
        if (!alive()) {
            Toast.makeText(this, "Shizuku não está ativo.", Toast.LENGTH_LONG).show()
            return
        }
        if (!granted()) {
            Toast.makeText(this, "Falta a permissão (botão 1).", Toast.LENGTH_LONG).show()
            return
        }
        virtBtn.isEnabled = false
        runBtn.isEnabled = false
        vRecognized = false
        vInfo = ""
        vCount = 0
        vMin = 999f
        vMax = -999f
        output.text = "Criando o controle virtual por uns 9 segundos...\nNão toque em nada e deixe esta tela aberta."

        val apk = applicationInfo.sourceDir
        thread {
            val raw = shell("CLASSPATH='$apk' app_process /system/bin com.example.sticklab.VirtualPad 6")
            Thread.sleep(600)
            runOnUiThread {
                val stillThere = InputDevice.getDeviceIds().any {
                    InputDevice.getDevice(it)?.name == VNAME
                }
                val sb = StringBuilder()
                sb.append("=== RESULTADO DO TESTE ===\n")
                sb.append("Android reconheceu o controle virtual: ")
                sb.append(if (vRecognized) "SIM ($vInfo)" else "NÃO").append("\n")
                sb.append("Eventos recebidos dele nesta tela: $vCount\n")
                if (vCount > 0) {
                    sb.append("Faixa do eixo X: ${"%.2f".format(vMin)} a ${"%.2f".format(vMax)}")
                    sb.append(" (esperado perto de -0.86 a 0.86)\n")
                }
                sb.append("Controle virtual removido no fim: ")
                sb.append(if (stillThere) "NÃO" else "SIM").append("\n\n")
                sb.append("--- Saída do programa ---\n").append(raw)
                output.text = sb.toString()
                virtBtn.isEnabled = true
                runBtn.isEnabled = true
            }
        }
    }

    private fun findPadPath(listing: String): String? {
        var path: String? = null
        for (line in listing.lines()) {
            val t = line.trim()
            if (t.startsWith("add device")) {
                path = t.substringAfter(": ", "").trim()
            } else if (t.startsWith("name:") && t.contains("\"Wireless Controller\"")) {
                return path
            }
        }
        return null
    }

    private fun finishGrabTest(text: String) {
        grabTesting = false
        output.text = text
        virtBtn.isEnabled = true
        grabBtn.isEnabled = true
        runBtn.isEnabled = true
    }

    private fun runGrabTest() {
        if (!alive()) {
            Toast.makeText(this, "Shizuku não está ativo.", Toast.LENGTH_LONG).show()
            return
        }
        if (!granted()) {
            Toast.makeText(this, "Falta a permissão (botão 1).", Toast.LENGTH_LONG).show()
            return
        }
        virtBtn.isEnabled = false
        grabBtn.isEnabled = false
        runBtn.isEnabled = false
        padEvents.clear()
        grabTesting = true
        output.text = "Teste de bloqueio: leva uns 15 segundos.\n" +
            "Fique mexendo os DOIS analógicos sem parar, até aparecer o resultado.\n" +
            "Deixe esta tela aberta."

        val apk = applicationInfo.sourceDir
        thread {
            val listing = shell("getevent -pl")
            val path = findPadPath(listing)
            if (path == null) {
                runOnUiThread {
                    finishGrabTest("Não achei o \"Wireless Controller\" na lista.\nConecte o PS4 e tente de novo.")
                }
                return@thread
            }
            val raw = shell("CLASSPATH='$apk' app_process /system/bin com.example.sticklab.GrabTest $path")
            Thread.sleep(500)
            runOnUiThread {
                val on = Regex("T_GRAB_ON=(\\d+)").find(raw)?.groupValues?.get(1)?.toLongOrNull()
                val off = Regex("T_GRAB_OFF=(\\d+)").find(raw)?.groupValues?.get(1)?.toLongOrNull()
                val sb = StringBuilder()
                sb.append("=== RESULTADO DO BLOQUEIO ===\n")
                if (on == null || off == null) {
                    sb.append("O bloqueio NÃO foi aplicado (veja a saída do programa abaixo).\n")
                } else {
                    val before = padEvents.count { it >= on - 4000 && it < on }
                    val during = padEvents.count { it >= on + 300 && it < off }
                    val after = padEvents.count { it >= off && it < off + 4000 }
                    sb.append("Movimentos que o app recebeu do PS4:\n")
                    sb.append("  antes do bloqueio: $before\n")
                    sb.append("  durante o bloqueio: $during\n")
                    sb.append("  depois de soltar: $after\n\n")
                    val verdict = when {
                        before < 10 ->
                            "Quase nada chegou antes do bloqueio. Mexa os analógicos durante o teste e rode de novo."
                        during <= maxOf(3, before / 20) ->
                            "BLOQUEIO FUNCIONOU: o app parou de receber o controle real."
                        else ->
                            "BLOQUEIO NÃO funcionou: o app continuou recebendo o controle real."
                    }
                    sb.append(verdict).append("\n")
                }
                sb.append("\n--- Saída do programa ---\n").append(raw)
                finishGrabTest(sb.toString())
            }
        }
    }

    private fun runDiagnostic() {
        if (!alive()) {
            Toast.makeText(this, "Shizuku não está ativo.", Toast.LENGTH_LONG).show()
            return
        }
        if (!granted()) {
            Toast.makeText(this, "Falta a permissão (botão 1).", Toast.LENGTH_LONG).show()
            return
        }
        runBtn.isEnabled = false
        output.text = "Rodando..."

        val tests = listOf(
            "Aparelho" to "getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk",
            "Quem sou eu" to "id",
            "Arquivos de entrada (/dev/input)" to "ls -l /dev/input",
            "O shell consegue LER cada dispositivo?" to
                "for f in /dev/input/event*; do if [ -r \"\$f\" ]; then echo \"\$f: leitura OK\"; else echo \"\$f: SEM leitura\"; fi; done",
            "uinput (criar controle virtual)" to
                "ls -l /dev/uinput; if [ -w /dev/uinput ]; then echo 'escrita OK'; else echo 'SEM escrita'; fi",
            "Lista de dispositivos de entrada" to
                "cat /proc/bus/input/devices | grep -E '^(N:|H:)'",
            "Eixos e botões (getevent)" to "getevent -pl | head -n 120"
        )

        thread {
            val sb = StringBuilder()
            for ((title, cmd) in tests) {
                sb.append("=== ").append(title).append(" ===\n")
                sb.append(shell(cmd)).append("\n\n")
            }
            runOnUiThread {
                output.text = sb.toString()
                runBtn.isEnabled = true
            }
        }
    }
}
