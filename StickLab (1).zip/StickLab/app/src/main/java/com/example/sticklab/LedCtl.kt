package com.example.sticklab

/**
 * Cor do LED do controle, pelo sistema de LEDs do kernel (/sys/class/leds).
 * Roda comandos pelo Shizuku. Pode ser bloqueado pelo Android/Samsung (permissão ou SELinux);
 * nesse caso o resultado diz o motivo.
 */
object LedCtl {
    private const val DIR = "/sys/class/leds"
    private val KEYS = listOf("054c", "playstation", "sony", "dualshock", "wireless")

    /** Um conjunto de LEDs do controle: vermelho/verde/azul separados, ou um LED multicolor. */
    class Group(val red: String?, val green: String?, val blue: String?, val multi: String?)

    private fun names(): List<String> =
        PadEngineCtl.sh("ls $DIR").lines().map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("ERRO") && !it.contains(" ") }

    private fun isPad(n: String) = KEYS.any { n.lowercase().contains(it) }

    fun find(): List<Group> {
        val bases = LinkedHashMap<String, Array<String?>>()
        val multis = ArrayList<String>()
        for (n in names().filter { isPad(it) }) {
            val l = n.lowercase()
            when {
                l.endsWith(":red") -> bases.getOrPut(n.dropLast(4)) { arrayOfNulls(3) }[0] = n
                l.endsWith(":green") -> bases.getOrPut(n.dropLast(6)) { arrayOfNulls(3) }[1] = n
                l.endsWith(":blue") -> bases.getOrPut(n.dropLast(5)) { arrayOfNulls(3) }[2] = n
                l.contains("rgb") -> multis.add(n)
            }
        }
        val out = ArrayList<Group>()
        for ((_, a) in bases) out.add(Group(a[0], a[1], a[2], null))
        for (m in multis) out.add(Group(null, null, null, m))
        return out
    }

    /** Aplica a cor (0..255 cada). Devolve um texto dizendo se funcionou. */
    fun set(r: Int, g: Int, b: Int): String {
        val groups = find()
        if (groups.isEmpty()) return "Nenhum LED de controle encontrado em /sys/class/leds."
        val cmd = StringBuilder()
        for (gr in groups) {
            if (gr.red != null) cmd.append("echo $r > '$DIR/${gr.red}/brightness'; ")
            if (gr.green != null) cmd.append("echo $g > '$DIR/${gr.green}/brightness'; ")
            if (gr.blue != null) cmd.append("echo $b > '$DIR/${gr.blue}/brightness'; ")
            if (gr.multi != null) {
                cmd.append("echo '$r $g $b' > '$DIR/${gr.multi}/multi_intensity'; ")
                cmd.append("echo 255 > '$DIR/${gr.multi}/brightness'; ")
            }
        }
        val out = PadEngineCtl.sh(cmd.toString())
        return if (out.isBlank()) "OK: cor aplicada (R$r G$g B$b) em ${groups.size} LED(s)."
        else "FALHOU: $out"
    }

    /** Cor atual (para restaurar depois de um teste). Null se não der para ler. */
    fun get(): Triple<Int, Int, Int>? {
        val gr = find().firstOrNull { it.red != null && it.green != null && it.blue != null } ?: return null
        fun rd(n: String) = PadEngineCtl.sh("cat '$DIR/$n/brightness'").trim().toIntOrNull()
        val r = rd(gr.red!!) ?: return null
        val g = rd(gr.green!!) ?: return null
        val b = rd(gr.blue!!) ?: return null
        return Triple(r, g, b)
    }

    /** Texto para o diagnóstico. */
    fun report(): String {
        val sb = StringBuilder()
        sb.appendLine("SELinux: " + PadEngineCtl.sh("getenforce"))
        val all = names()
        if (all.isEmpty()) {
            sb.appendLine("Não consegui listar $DIR:")
            sb.appendLine(PadEngineCtl.sh("ls $DIR").take(300))
        } else {
            sb.appendLine("LEDs no sistema (${all.size}): " + all.take(40).joinToString(", "))
        }
        val groups = find()
        sb.appendLine("LEDs do controle encontrados: ${groups.size}")
        for (gr in groups) {
            val sample = gr.red ?: gr.multi
            if (sample != null) {
                sb.appendLine(sample + ": " + PadEngineCtl.sh("ls -l '$DIR/$sample/brightness'"))
                sb.appendLine("  max_brightness: " + PadEngineCtl.sh("cat '$DIR/$sample/max_brightness'"))
            }
        }
        return sb.toString().trimEnd()
    }
}
