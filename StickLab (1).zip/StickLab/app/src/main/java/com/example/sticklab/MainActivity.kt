package com.example.sticklab

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.concurrent.thread
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private enum class Step { IDLE, SOURCE, TARGET, TURBO }

    private lateinit var store: ProfileStore
    private lateinit var profile: Profile
    private lateinit var pad: GamepadView
    private lateinit var status: TextView
    private lateinit var remapBtn: Button
    private lateinit var remapInfo: TextView
    private lateinit var turboBtn: Button
    private lateinit var turboInfo: TextView
    private lateinit var panel: LinearLayout
    private lateinit var ledSwatch: TextView
    private lateinit var ledInfo: TextView
    private val ledBars = arrayOfNulls<SeekBar>(3)
    private var engineText = "Motor: verificando..."
    private var device: InputDevice? = null

    // Motor (roda em segundo plano pelo Shizuku)
    private lateinit var engineStatus: TextView
    private var engineOn = false
    private val handler = Handler(Looper.getMainLooper())
    private val statusTick = object : Runnable {
        override fun run() {
            thread {
                val s = PadEngineCtl.status()
                runOnUiThread { applyEngineStatus(s) }
            }
            handler.postDelayed(this, 2500)
        }
    }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            runOnUiThread { startEngine() }
        }
    }

    // Remapeamento
    private var step = Step.IDLE
    private var source = 0

    // O D-pad do DS4 chega como eixo (hat). Eu converto em botões virtuais para poder remapear.
    private var lastHx = 0f
    private var lastHy = 0f
    private val hatHeld = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
        profile = store.load(store.activeName())

        pad = GamepadView(this).also { it.profile = profile }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        buildPanel()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(18, 18, 24))
        }
        root.addView(pad, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 3f))
        root.addView(ScrollView(this).apply { addView(panel) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.3f))
        setContentView(root)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    /** Monta (ou remonta, ao trocar de perfil) todos os controles do painel lateral. */
    private fun buildPanel() {
        panel.removeAllViews()
        status = label(if (device != null) status.text.toString() else "Conecte o controle e mexa em qualquer botão.")
        panel.addView(status)

        // ---- Motor (vale dentro dos jogos) ----
        panel.addView(label("\nMotor (vale dentro dos jogos)").apply { textSize = 16f })
        engineStatus = label(engineText)
        panel.addView(engineStatus)
        panel.addView(Button(this).apply {
            text = "Ativar motor (Shizuku)"
            setOnClickListener { startEngine() }
        })
        panel.addView(Button(this).apply {
            text = "Desativar motor"
            setOnClickListener { stopEngine() }
        })
        panel.addView(label("Com o motor ativo, o PS4 passa por aqui e os ajustes valem em qualquer jogo. Ative antes de abrir o jogo.").apply { textSize = 12f })

        // ---- Perfis ----
        panel.addView(label("\nPerfil").apply { textSize = 16f })
        val names = store.names()
        panel.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, names).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(names.indexOf(profile.name).coerceAtLeast(0), false)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                    val n = names[pos]
                    if (n != profile.name) switchProfile(n)
                }
                override fun onNothingSelected(parent: AdapterView<*>) {}
            }
        })
        panel.addView(Button(this).apply {
            text = "Novo perfil (copia o atual)"
            setOnClickListener { askNewProfile() }
        })
        panel.addView(Button(this).apply {
            text = "Excluir este perfil"
            setOnClickListener { askDeleteProfile() }
        })

        // ---- Analógico esquerdo ----
        panel.addView(label("\nAnalógico esquerdo").apply { textSize = 16f })
        panel.addView(zoneSlider("Zona morta", { profile.left.deadzone }) { profile.left.deadzone = it })
        panel.addView(curveSlider("Curva (1.0 = linear)", { profile.left.curve }) { profile.left.curve = it })

        // ---- Analógico direito ----
        panel.addView(label("\nAnalógico direito").apply { textSize = 16f })
        panel.addView(zoneSlider("Zona morta", { profile.right.deadzone }) { profile.right.deadzone = it })
        panel.addView(curveSlider("Curva (1.0 = linear)", { profile.right.curve }) { profile.right.curve = it })

        panel.addView(CheckBox(this).apply {
            text = "Inverter eixo Y (os dois analógicos)"
            setTextColor(Color.WHITE)
            isChecked = profile.invertY
            setOnCheckedChangeListener { _, checked ->
                profile.invertY = checked
                store.save(profile)
                pushEngine()
                pad.invalidate()
            }
        })

        // ---- Gatilhos ----
        panel.addView(label("\nGatilho L2").apply { textSize = 16f })
        panel.addView(triggerStartSlider("Zona morta inicial", { profile.lt.start }) { profile.lt.start = it })
        panel.addView(triggerMaxSlider("Chega ao máximo em", { profile.lt.max }) { profile.lt.max = it })
        panel.addView(curveSlider("Curva (1.0 = linear)", { profile.lt.curve }) { profile.lt.curve = it })

        panel.addView(label("\nGatilho R2").apply { textSize = 16f })
        panel.addView(triggerStartSlider("Zona morta inicial", { profile.rt.start }) { profile.rt.start = it })
        panel.addView(triggerMaxSlider("Chega ao máximo em", { profile.rt.max }) { profile.rt.max = it })
        panel.addView(curveSlider("Curva (1.0 = linear)", { profile.rt.curve }) { profile.rt.curve = it })

        // ---- Vibração ----
        panel.addView(label("\nVibração").apply { textSize = 16f })
        panel.addView(slider("Intensidade", (profile.vibration * 100).toInt(),
            { "$it%" }) {
            profile.vibration = it / 100f
        })
        panel.addView(Button(this).apply {
            text = "Testar vibração"
            setOnClickListener { testVibration() }
        })

        // ---- LED ----
        panel.addView(label("\nLED do controle (experimental)").apply { textSize = 16f })
        panel.addView(CheckBox(this).apply {
            text = "Usar cor personalizada"
            setTextColor(Color.WHITE)
            isChecked = profile.led
            setOnCheckedChangeListener { _, checked ->
                profile.led = checked
                store.save(profile)
                if (checked) applyLed() else {
                    pushEngine()
                    ledInfo.text = "Desligado. Reconecte o controle para voltar à cor padrão."
                }
            }
        })
        ledSwatch = label("   ").apply { textSize = 22f }
        panel.addView(ledSwatch)
        panel.addView(ledSlider("Vermelho", 0, { profile.ledR }) { profile.ledR = it })
        panel.addView(ledSlider("Verde", 1, { profile.ledG }) { profile.ledG = it })
        panel.addView(ledSlider("Azul", 2, { profile.ledB }) { profile.ledB = it })
        panel.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val presets = listOf(
                "Verm." to Triple(255, 0, 0), "Verde" to Triple(0, 255, 0), "Azul" to Triple(0, 80, 255),
                "Roxo" to Triple(160, 0, 255), "Branco" to Triple(255, 255, 255)
            )
            for ((n, c) in presets) {
                addView(Button(this@MainActivity).apply {
                    text = n
                    textSize = 11f
                    setPadding(4, 0, 4, 0)
                    setOnClickListener { setLedColor(c.first, c.second, c.third) }
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        })
        ledInfo = label("Mexa nos controles e solte para aplicar. O resultado aparece aqui.").apply { textSize = 12f }
        panel.addView(ledInfo)
        updateSwatch()

        // ---- Turbo ----
        panel.addView(label("\nTurbo").apply { textSize = 16f })
        panel.addView(slider("Velocidade", ((profile.turboRate - 5f) / 20f * 100).toInt().coerceIn(0, 100),
            { "%.0f cliques/s".format(5f + it / 100f * 20f) }) {
            profile.turboRate = 5f + it / 100f * 20f
        })
        turboBtn = Button(this).apply {
            text = "Escolher botões com turbo"
            setOnClickListener { toggleTurbo() }
        }
        panel.addView(turboBtn)
        panel.addView(Button(this).apply {
            text = "Limpar turbo"
            setOnClickListener {
                profile.turbo.clear()
                store.save(profile)
                pushEngine()
                if (step == Step.TURBO) { step = Step.IDLE; turboBtn.text = "Escolher botões com turbo" }
                refreshTurboInfo()
            }
        })
        turboInfo = label("")
        panel.addView(turboInfo)
        refreshTurboInfo()

        // ---- Remapeamento ----
        panel.addView(label("\nRemapeamento de botões").apply { textSize = 16f })
        remapBtn = Button(this).apply {
            text = "Remapear um botão"
            setOnClickListener { toggleRemap() }
        }
        panel.addView(remapBtn)
        panel.addView(Button(this).apply {
            text = "Limpar remapeamentos"
            setOnClickListener {
                profile.remap.clear()
                store.save(profile)
                pushEngine()
                step = Step.IDLE
                remapBtn.text = "Remapear um botão"
                pad.state.pressed.clear()
                hatHeld.clear()
                refreshRemapInfo()
                pad.invalidate()
            }
        })
        remapInfo = label("")
        panel.addView(remapInfo)
        refreshRemapInfo()

        panel.addView(Button(this).apply {
            text = "Diagnóstico (Shizuku)"
            setOnClickListener { startActivity(Intent(this@MainActivity, DiagActivity::class.java)) }
        })
    }

    // ---- LED ----

    private fun updateSwatch() {
        ledSwatch.setBackgroundColor(Color.rgb(profile.ledR, profile.ledG, profile.ledB))
    }

    /** Slider 0..255 de uma cor do LED. O índice guarda a barra para os atalhos de cor poderem mexer nela. */
    private fun ledSlider(name: String, idx: Int, get: () -> Int, set: (Int) -> Unit): LinearLayout {
        val title = label("$name: ${get()}")
        val bar = SeekBar(this).apply {
            max = 255
            progress = get()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    title.text = "$name: $p"
                    set(p)
                    updateSwatch()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {
                    profile.led = true
                    store.save(profile)
                    applyLed()
                }
            })
        }
        ledBars[idx] = bar
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8, 0, 8)
            addView(title)
            addView(bar)
        }
    }

    private fun setLedColor(r: Int, g: Int, b: Int) {
        profile.ledR = r; profile.ledG = g; profile.ledB = b
        profile.led = true
        ledBars[0]?.progress = r
        ledBars[1]?.progress = g
        ledBars[2]?.progress = b
        updateSwatch()
        store.save(profile)
        applyLed()
    }

    /** Aplica a cor agora (pelo Shizuku) e também manda para o motor, que reaplica quando o controle reconecta. */
    private fun applyLed() {
        if (!profile.led) return
        pushEngine()
        if (!PadEngineCtl.alive() || !PadEngineCtl.granted()) {
            ledInfo.text = "Precisa do Shizuku ativo e liberado para mudar o LED."
            return
        }
        val r = profile.ledR; val g = profile.ledG; val b = profile.ledB
        thread {
            val res = LedCtl.set(r, g, b)
            runOnUiThread { ledInfo.text = res }
        }
    }

    // ---- Perfis ----

    private fun switchProfile(name: String, saveCurrent: Boolean = true) {
        if (saveCurrent) store.save(profile)
        profile = store.load(name)
        store.setActive(name)
        pad.profile = profile
        step = Step.IDLE
        pad.state.pressed.clear()
        hatHeld.clear()
        buildPanel()
        pushEngine()
        if (profile.led) applyLed()
        pad.invalidate()
    }

    private fun askNewProfile() {
        val input = EditText(this).apply { hint = "Nome do perfil"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Novo perfil")
            .setMessage("Ele começa com os mesmos ajustes do perfil atual.")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Criar") { _, _ ->
                val n = input.text.toString().replace("\n", " ").trim().take(24)
                when {
                    n.isEmpty() -> Toast.makeText(this, "Digite um nome.", Toast.LENGTH_SHORT).show()
                    n in store.names() -> Toast.makeText(this, "Já existe um perfil com esse nome.", Toast.LENGTH_SHORT).show()
                    else -> {
                        val copy = profile.snapshot().also { it.name = n }
                        store.save(copy)
                        switchProfile(n)
                    }
                }
            }
            .show()
    }

    private fun askDeleteProfile() {
        if (store.names().size <= 1) {
            Toast.makeText(this, "Precisa existir pelo menos um perfil.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Excluir \"${profile.name}\"?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Excluir") { _, _ ->
                store.delete(profile.name)
                switchProfile(store.activeName(), saveCurrent = false)
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        handler.post(statusTick)
    }

    override fun onPause() {
        handler.removeCallbacks(statusTick)
        super.onPause()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    // ---- Motor ----

    private fun applyEngineStatus(s: String) {
        engineOn = s.startsWith("RODANDO")
        engineText = when {
            s.startsWith("SEM_SHIZUKU") -> "Motor: parado. O Shizuku não está ativo (abra o app Shizuku e toque em Iniciar)."
            s.startsWith("SEM_PERMISSAO") -> "Motor: parado. Toque em Ativar e aceite a permissão do Shizuku."
            s.startsWith("PARADO") -> "Motor: parado."
            s.startsWith("RODANDO") -> "Motor: ativo.\n" + s.removePrefix("RODANDO").trim()
            else -> "Motor: $s"
        }
        engineStatus.text = engineText
    }

    private fun snapshot(): Profile = profile.snapshot()

    private fun pushEngine() {
        if (!engineOn) return
        val snap = snapshot()
        thread { PadEngineCtl.pushConfig(snap) }
    }

    private fun startEngine() {
        if (!PadEngineCtl.alive()) {
            Toast.makeText(this, "Shizuku não está ativo. Abra o app Shizuku e toque em Iniciar.", Toast.LENGTH_LONG).show()
            return
        }
        if (!PadEngineCtl.granted()) {
            try {
                if (Shizuku.shouldShowRequestPermissionRationale()) {
                    Toast.makeText(this, "Permissão negada antes. Libere o StickLab dentro do app Shizuku.", Toast.LENGTH_LONG).show()
                } else {
                    Shizuku.requestPermission(1002)
                }
            } catch (t: Throwable) {
                Toast.makeText(this, "Erro: $t", Toast.LENGTH_LONG).show()
            }
            return
        }
        engineStatus.text = "Motor: iniciando..."
        val apk = applicationInfo.sourceDir
        val snap = snapshot()
        thread {
            PadEngineCtl.start(apk, snap)
            Thread.sleep(2500)
            val s = PadEngineCtl.status()
            runOnUiThread { applyEngineStatus(s) }
        }
    }

    private fun stopEngine() {
        if (!PadEngineCtl.alive() || !PadEngineCtl.granted()) {
            applyEngineStatus(PadEngineCtl.status())
            return
        }
        engineStatus.text = "Motor: parando..."
        thread {
            PadEngineCtl.stop()
            val s = PadEngineCtl.status()
            runOnUiThread { applyEngineStatus(s) }
        }
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE) }

    private fun slider(name: String, start: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): LinearLayout {
        val title = label("$name: ${fmt(start)}")
        val bar = SeekBar(this).apply {
            max = 100
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    title.text = "$name: ${fmt(p)}"
                    onChange(p)
                    pad.invalidate()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { store.save(profile); pushEngine() }
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 16, 0, 16)
            addView(title)
            addView(bar)
        }
    }

    private fun zoneSlider(name: String, get: () -> Float, set: (Float) -> Unit) =
        slider(name, (get() / 0.5f * 100).toInt().coerceIn(0, 100),
            { "%.0f%%".format(it / 100f * 0.5f * 100) }) { set(it / 100f * 0.5f) }

    private fun curveSlider(name: String, get: () -> Float, set: (Float) -> Unit) =
        slider(name, ((get() - 0.5f) / 2.5f * 100).toInt().coerceIn(0, 100),
            { "%.2f".format(0.5f + it / 100f * 2.5f) }) { set(0.5f + it / 100f * 2.5f) }

    // Zona morta inicial do gatilho: 0% a 40%.
    private fun triggerStartSlider(name: String, get: () -> Float, set: (Float) -> Unit) =
        slider(name, (get() / 0.4f * 100).toInt().coerceIn(0, 100),
            { "%.0f%%".format(it / 100f * 0.4f * 100) }) { set(it / 100f * 0.4f) }

    // Onde o gatilho chega ao máximo: 50% a 100% do curso (menos = curso mais curto).
    private fun triggerMaxSlider(name: String, get: () -> Float, set: (Float) -> Unit) =
        slider(name, ((get() - 0.5f) / 0.5f * 100).toInt().coerceIn(0, 100),
            { "%.0f%% do curso".format((0.5f + it / 100f * 0.5f) * 100) }) { set(0.5f + it / 100f * 0.5f) }

    // ---- Turbo: aperte os botões que devem ter turbo (aperte de novo para tirar) ----

    private fun toggleTurbo() {
        if (step == Step.TURBO) {
            step = Step.IDLE
            turboBtn.text = "Escolher botões com turbo"
            refreshTurboInfo()
            return
        }
        if (step != Step.IDLE) {
            Toast.makeText(this, "Termine ou cancele o remapeamento antes.", Toast.LENGTH_SHORT).show()
            return
        }
        if (engineOn) {
            Toast.makeText(this, "Desative o motor para escolher os botões do turbo.", Toast.LENGTH_LONG).show()
            return
        }
        step = Step.TURBO
        turboBtn.text = "Concluir"
        turboInfo.text = "Aperte no controle os botões que terão turbo (aperte de novo para tirar). Depois toque em Concluir."
    }

    private fun refreshTurboInfo() {
        turboInfo.text = if (profile.turbo.isEmpty()) {
            "Nenhum botão com turbo."
        } else {
            "Turbo em: " + profile.turbo.sorted().joinToString(", ") { buttonName(it) }
        }
    }

    // ---- Remapeamento: 1) aperte o botão a trocar  2) aperte o botão que ele deve virar ----

    private fun toggleRemap() {
        if (step == Step.TURBO) {
            Toast.makeText(this, "Toque em Concluir no turbo antes.", Toast.LENGTH_SHORT).show()
            return
        }
        if (step == Step.IDLE) {
            if (engineOn) {
                Toast.makeText(this, "Desative o motor para criar remapeamentos.", Toast.LENGTH_LONG).show()
                return
            }
            step = Step.SOURCE
            remapBtn.text = "Cancelar"
            remapInfo.text = "Passo 1: aperte no controle o botão que você quer trocar."
        } else {
            step = Step.IDLE
            remapBtn.text = "Remapear um botão"
            refreshRemapInfo()
        }
    }

    private fun handleRemapPress(code: Int) {
        when (step) {
            Step.SOURCE -> {
                source = code
                step = Step.TARGET
                remapInfo.text = "Passo 2: ${buttonName(code)} vai virar qual botão? Aperte o botão de destino.\n(Aperte o mesmo botão para desfazer a troca.)"
            }
            Step.TARGET -> {
                if (code == source) profile.remap.remove(source) else profile.remap[source] = code
                store.save(profile)
                pushEngine()
                step = Step.IDLE
                remapBtn.text = "Remapear um botão"
                pad.state.pressed.clear()
                hatHeld.clear()
                refreshRemapInfo()
                pad.invalidate()
            }
            Step.TURBO -> {
                if (code !in TURBO_KEYS) {
                    Toast.makeText(this, "Turbo só funciona em botões (não no D-pad).", Toast.LENGTH_SHORT).show()
                } else {
                    if (!profile.turbo.add(code)) profile.turbo.remove(code)
                    store.save(profile)
                    pushEngine()
                    turboInfo.text = "Aperte os botões com turbo (de novo para tirar); depois toque em Concluir.\n" +
                        if (profile.turbo.isEmpty()) "Nenhum até agora."
                        else "Turbo em: " + profile.turbo.sorted().joinToString(", ") { buttonName(it) }
                }
            }
            Step.IDLE -> {}
        }
    }

    private fun refreshRemapInfo() {
        remapInfo.text = if (profile.remap.isEmpty()) {
            "Nenhum remapeamento. Aperte um botão para ver como fica."
        } else {
            profile.remap.entries.joinToString("\n") {
                "${buttonName(it.key)} → ${buttonName(it.value)}"
            }
        }
    }

    // ---- Entrada do controle ----

    private fun handleHat(hx: Float, hy: Float) {
        if (hx == lastHx && hy == lastHy) return
        lastHx = hx
        lastHy = hy
        pad.state.pressed.removeAll(hatHeld)
        hatHeld.clear()
        val raw = listOfNotNull(
            if (hy < -0.5f) KeyEvent.KEYCODE_DPAD_UP else null,
            if (hy > 0.5f) KeyEvent.KEYCODE_DPAD_DOWN else null,
            if (hx < -0.5f) KeyEvent.KEYCODE_DPAD_LEFT else null,
            if (hx > 0.5f) KeyEvent.KEYCODE_DPAD_RIGHT else null
        )
        if (step != Step.IDLE) {
            val first = raw.firstOrNull()
            if (first != null) handleRemapPress(first)
        } else {
            for (code in raw) {
                val mapped = if (pad.passthrough) code else profile.map(code)
                hatHeld.add(mapped)
                pad.state.pressed.add(mapped)
            }
        }
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(InputDevice.SOURCE_JOYSTICK) && e.action == MotionEvent.ACTION_MOVE) {
            pad.passthrough = e.device?.name == PadEngineCtl.DEVICE_NAME
            val s = pad.state
            s.lx = e.getAxisValue(MotionEvent.AXIS_X)
            s.ly = e.getAxisValue(MotionEvent.AXIS_Y)
            s.rx = e.getAxisValue(MotionEvent.AXIS_Z)
            s.ry = e.getAxisValue(MotionEvent.AXIS_RZ)
            s.lt = max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE))
            s.rt = max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
            handleHat(e.getAxisValue(MotionEvent.AXIS_HAT_X), e.getAxisValue(MotionEvent.AXIS_HAT_Y))
            setDevice(e.device)
            pad.invalidate()
            return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val fromPad = e.isFromSource(InputDevice.SOURCE_GAMEPAD) || e.isFromSource(InputDevice.SOURCE_DPAD)
        val isPadKey = KeyEvent.isGamepadButton(e.keyCode) ||
            e.keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
        if (!fromPad || !isPadKey) return super.dispatchKeyEvent(e)

        setDevice(e.device)
        pad.passthrough = e.device?.name == PadEngineCtl.DEVICE_NAME

        if (step != Step.IDLE) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) handleRemapPress(e.keyCode)
            return true
        }

        val mapped = if (pad.passthrough) e.keyCode else profile.map(e.keyCode)
        if (e.action == KeyEvent.ACTION_DOWN) pad.state.pressed.add(mapped)
        else if (e.action == KeyEvent.ACTION_UP) pad.state.pressed.remove(mapped)
        pad.invalidate()
        return true
    }

    private fun setDevice(d: InputDevice?) {
        if (d == null || d.id == device?.id) return
        device = d
        var info = "Controle: ${d.name}"
        if (Build.VERSION.SDK_INT >= 31) {
            val b = d.batteryState
            if (b.isPresent && !b.capacity.isNaN()) info += "\nBateria: ${(b.capacity * 100).toInt()}%"
        }
        status.text = info
    }

    private fun testVibration() {
        val d = device ?: return
        val amp = max(1, (profile.vibration * 255).toInt())
        if (Build.VERSION.SDK_INT >= 31) {
            val v = d.vibratorManager.defaultVibrator
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(400, amp))
        } else {
            @Suppress("DEPRECATION")
            d.vibrator.vibrate(400)
        }
    }
}
