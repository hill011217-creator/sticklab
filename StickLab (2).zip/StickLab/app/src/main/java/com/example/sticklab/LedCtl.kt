package com.example.sticklab

import android.graphics.Color
import android.hardware.lights.LightState
import android.hardware.lights.LightsManager
import android.hardware.lights.LightsRequest
import android.os.Build
import android.view.InputDevice

/**
 * Cor do LED do controle pela API oficial de luzes do Android (12+): InputDevice.lightsManager.
 * Não precisa de Shizuku. A cor vale enquanto a "sessão" estiver aberta (enquanto o app estiver
 * vivo); ao fechar a sessão o controle volta à cor padrão.
 */
object LedCtl {
    private var session: LightsManager.LightsSession? = null
    private var sessionDeviceId = -1

    private fun devices(): List<InputDevice> =
        InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) }

    /** Controle com luz RGB (ignora o controle virtual do próprio app). */
    private fun rgbDevice(): InputDevice? {
        if (Build.VERSION.SDK_INT < 31) return null
        return devices().firstOrNull { d ->
            !d.name.startsWith("StickLab") &&
                try { d.lightsManager.lights.any { it.hasRgbControl() } } catch (t: Throwable) { false }
        }
    }

    /** Aplica a cor (0..255 cada). Devolve um texto dizendo se funcionou. */
    fun set(r: Int, g: Int, b: Int): String {
        if (Build.VERSION.SDK_INT < 31) return "Precisa de Android 12 ou mais novo."
        val dev = rgbDevice()
            ?: return "O Android não achou nenhum controle com LED RGB. Ligue o controle e tente de novo."
        return try {
            val lm = dev.lightsManager
            val lights = lm.lights.filter { it.hasRgbControl() }
            var s = session
            if (s == null || sessionDeviceId != dev.id) {
                try { s?.close() } catch (t: Throwable) { }
                s = lm.openSession()
                session = s
                sessionDeviceId = dev.id
            }
            @Suppress("DEPRECATION")
            val state = LightState(Color.rgb(r, g, b))
            val req = LightsRequest.Builder()
            for (l in lights) req.addLight(l, state)
            s!!.requestLights(req.build())
            "OK: cor aplicada (R$r G$g B$b) em ${lights.size} luz(es) de \"${dev.name}\"."
        } catch (t: Throwable) {
            session = null
            sessionDeviceId = -1
            "FALHOU: $t"
        }
    }

    /** Fecha a sessão: o controle volta à cor padrão. */
    fun release() {
        try { session?.close() } catch (t: Throwable) { }
        session = null
        sessionDeviceId = -1
    }

    /** Texto para o diagnóstico. */
    fun report(): String {
        val sb = StringBuilder()
        sb.appendLine("Android API ${Build.VERSION.SDK_INT}")
        if (Build.VERSION.SDK_INT < 31) {
            sb.appendLine("LightsManager só existe no Android 12+ (API 31).")
            return sb.toString().trimEnd()
        }
        for (d in devices()) {
            val pad = d.supportsSource(InputDevice.SOURCE_GAMEPAD) || d.supportsSource(InputDevice.SOURCE_JOYSTICK)
            if (!pad) continue
            sb.appendLine("Dispositivo: \"${d.name}\" (id ${d.id})")
            try {
                val lights = d.lightsManager.lights
                if (lights.isEmpty()) sb.appendLine("  sem luzes controláveis")
                for (l in lights) {
                    sb.appendLine("  luz \"${l.name}\" tipo=${l.type} rgb=${l.hasRgbControl()} brilho=${l.hasBrightnessControl()}")
                }
            } catch (t: Throwable) {
                sb.appendLine("  erro ao ler luzes: $t")
            }
        }
        return sb.toString().trimEnd()
    }
}
